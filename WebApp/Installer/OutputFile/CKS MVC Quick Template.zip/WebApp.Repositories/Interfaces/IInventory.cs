﻿namespace $safeprojectname$.Interfaces
{
    interface IInventory
    {
        //Should list all the DbSets or Interfaces containing DBsets for this feature
    }
}
