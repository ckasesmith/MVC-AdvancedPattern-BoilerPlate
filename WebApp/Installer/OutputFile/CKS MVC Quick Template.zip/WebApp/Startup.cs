﻿using Microsoft.Owin;
using Owin;
using $safeprojectname$;

[assembly: OwinStartup(typeof(Startup))]
namespace $safeprojectname$
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
